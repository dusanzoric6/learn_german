
Documentation
-------------

Load test for GitHub home page using Gatling. The load test simulates 1000 users within a set time frame of 15s.



Execution
-------------
```
 mvn gatling:test
```

Requirements
-------------
```
 java 11
 maven 3.8 
 scala 3.1.0
```

