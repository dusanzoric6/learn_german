package pages;

import org.openqa.selenium.WebDriver;

public class Page {

    public final WebDriver driver;

    public Page(WebDriver driver) {
        this.driver = driver;
    }
}
